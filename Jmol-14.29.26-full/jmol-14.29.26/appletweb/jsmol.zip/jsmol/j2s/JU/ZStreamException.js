Clazz.declarePackage ("JU");
Clazz.load (["java.io.IOException"], "JU.ZStreamException", null, function () {
c$ = Clazz.declareType (JU, "ZStreamException", java.io.IOException);
});
